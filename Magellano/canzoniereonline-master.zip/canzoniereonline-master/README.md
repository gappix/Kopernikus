canzoniereonline
================

The class used on www.canzoniereonline.it for the creation of songbooks online.

All available songs can be downloaded at https://www.dropbox.com/s/c9w3m540j45x4lr/canzoni_2017_09_10.zip?dl=0
