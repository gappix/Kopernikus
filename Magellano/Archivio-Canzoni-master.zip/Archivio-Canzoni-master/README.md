# Archivio-Canzoni

Tutte le canzoni in LaTeX di canzoniereonline.it. 
Non è possibile modificare direttamente i testi, ma è possibile proporre delle modifiche. Quindi se trovate delle inesattezze non abbiate paura di comunicarcele.
Sul sito canzoniereonline.it trovate le indicazioni su come trascrivere le canzoni in codice LaTeX
